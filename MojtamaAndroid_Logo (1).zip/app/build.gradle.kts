plugins { id("com.android.application") }
android {
 namespace = "ir.mojtama.manager"
 compileSdk = 35
 defaultConfig { applicationId = "ir.mojtama.manager"; minSdk = 24; targetSdk = 28; versionCode = 2; versionName = "1.1" }
 buildTypes { release { isMinifyEnabled = false } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
