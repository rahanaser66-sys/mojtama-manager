package ir.mojtama.manager;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.webkit.*;import android.view.*;
import androidx.webkit.WebViewAssetLoader;import androidx.webkit.WebViewClientCompat;
public class MainActivity extends Activity {
  private WebView web;
  private static final int FILE_PICK=100;
  private ValueCallback<Uri[]> fileCallback;
  private WebViewAssetLoader loader;
  @Override public void onCreate(Bundle state){super.onCreate(state);
    web=new WebView(this);setContentView(web);
    WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);
    loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
    web.setWebViewClient(new WebViewClientCompat(){
      @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
        try{startActivityForResult(params.createIntent(),FILE_PICK);return true;}catch(Exception e){fileCallback=null;return false;}
      }
    });
    web.setDownloadListener((url,userAgent,disposition,mimeType,length)->{
      try{
        if(url.startsWith("blob:")){
          new AlertDialog.Builder(this).setMessage("برای ذخیره نسخه پشتیبان، این قابلیت باید در نسخه اندروید آزمایش و تکمیل شود.").setPositiveButton("باشه",null).show();return;
        }
        Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));startActivity(intent);
      }catch(Exception ignored){}
    });
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==FILE_PICK && fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
